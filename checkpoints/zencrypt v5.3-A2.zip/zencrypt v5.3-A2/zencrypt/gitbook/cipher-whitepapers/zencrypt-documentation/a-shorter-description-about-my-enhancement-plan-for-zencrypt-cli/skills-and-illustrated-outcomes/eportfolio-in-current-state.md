---
icon: binary-lock
---

# ePortfolio in current state

### _**ePortfolio** and **GitHub** Screen Shots:_

**ePortfolio i**

![A screenshot of my website.](../../../../.gitbook/assets/0.png)

**ePortfolio ii**

![A screenshot of my Github and my ePortfolio reflecting updates.](../../../../.gitbook/assets/1.png)

###
