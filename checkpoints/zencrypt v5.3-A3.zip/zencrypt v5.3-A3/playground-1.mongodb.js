/*  MongoDB Playground script for inserting secrets into the keys collection */

const fs = require('fs');
const path = require('path');
const { MongoClient } = require('mongodb');
const crypto = require('crypto');

async function main() {
  const uri = 'mongodb+srv://zensilva:A65GAbbyWCSGWRTV@cluster02.gat1w.mongodb.net/' ;
  const client = new MongoClient(uri);

  try {
    await client.connect();
    const database = client.db('zencrypt');
    const collection = database.collection('keys');

    const secretsDir = '/etc/secrets/';
    const files = fs.readdirSync(secretsDir);

    for (const file of files) {
      const filePath = path.join(secretsDir, file);
      const secret = fs.readFileSync(filePath, 'utf8');

      // Generate a unique key
      const uniqueKey = crypto.randomBytes(32).toString('hex');

      await collection.insertOne({ key: uniqueKey, value: secret });
    }

    console.log('Secrets have been inserted into the keys collection.');
    const insertedSecret = await collection.findOne({ key: files  });
    console.log('Inserted secret:', insertedSecret);
  } finally {
    await client.close();
  }
}

main().catch(console.error);
