import React, { useState, useEffect } from 'react';
import { Alert, AlertTitle } from '@/components/ui/alert';
import { Lock, Mail, Key } from 'lucide-react';

const AuthComponent = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [error, setError] = useState('');
  const [keys, setKeys] = useState({ publicKey: null, privateKey: null });

  useEffect(() => {
    // Check for existing JWT token
    const token = localStorage.getItem('jwt_token');
    if (token) {
      validateToken(token);
    }
  }, []);

  const validateToken = async (token) => {
    try {
      const response = await fetch('/api/auth/validate', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
        setIsAuthenticated(true);
      } else {
        localStorage.removeItem('jwt_token');
        setIsAuthenticated(false);
      }
    } catch (err) {
      setError('Token validation failed');
    }
  };

  const generatePGPKeys = async () => {
    try {
      const response = await fetch('/api/keys/generate', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('jwt_token')}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const keyData = await response.json();
        setKeys(keyData);
        
        // Store keys in MongoDB associated with user
        await fetch('/api/keys/store', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('jwt_token')}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            userId: user.id,
            publicKey: keyData.publicKey
          })
        });
      }
    } catch (err) {
      setError('Failed to generate PGP keys');
    }
  };

  const handleLogin = async (email, password) => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      });

      if (response.ok) {
        const { token, user: userData } = await response.json();
        localStorage.setItem('jwt_token', token);
        setUser(userData);
        setIsAuthenticated(true);
      } else {
        setError('Invalid credentials');
      }
    } catch (err) {
      setError('Login failed');
    }
  };

  return (
    <div className="w-full max-w-md mx-auto p-6">
      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertTitle>{error}</AlertTitle>
        </Alert>
      )}

      {!isAuthenticated ? (
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-center">Login to Zencrypt</h2>
          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            handleLogin(formData.get('email'), formData.get('password'));
          }} className="space-y-4">
            <div className="flex items-center space-x-2">
              <Mail className="w-5 h-5" />
              <input
                type="email"
                name="email"
                placeholder="Email"
                className="w-full p-2 border rounded"
                required
              />
            </div>
            <div className="flex items-center space-x-2">
              <Lock className="w-5 h-5" />
              <input
                type="password"
                name="password"
                placeholder="Password"
                className="w-full p-2 border rounded"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700"
            >
              Login
            </button>
          </form>
        </div>
      ) : (
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">Welcome, {user?.email}</h2>
          {!keys.publicKey && (
            <button
              onClick={generatePGPKeys}
              className="flex items-center space-x-2 bg-green-600 text-white p-2 rounded hover:bg-green-700"
            >
              <Key className="w-5 h-5" />
              <span>Generate PGP Keys</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default AuthComponent;